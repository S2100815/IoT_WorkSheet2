﻿# MorseCode

This program converts Morse codeinput into text output.


## Materials Required

-   micro:bit (quantity 2)
-   USB cable
-   Crocodile Clips (quantity 2)


## Instructions
1.  Connect your micro:bit to your computer using the USB cable.
2.  Copy the code from morsecode.txt file and paste the code into the [MicroPython editor](https://python.microbit.org/v/2.0).
3.  Click on "Download" to download the hex file.
4.  Drag and drop the hex file onto your micro:bit to load the code onto the device. (upload the same code to both devices)
5.  Connect both devices to power.
6.  Connect a crocodile clip on ground to ground on both devices.
7.  Connect a crocodile clip line 1 on one end and line 2 of the second device on the other end.
8.  now you're ready to send morse code, press button A for Dot and button B for Dash.
10. User the morse code combination to retrieve the expected letter.

##Note

-   line 1 is the sender and line 2 is the receiver

Credits

This program was created by Ali Sharaf Ahmed as a personal project.
